#include "simulation.h"
#include "constantes.h"

int main (int argc, char *argv[])
{
	
	Simulation simulation;
	simulation.lecture(argv[1]);
	return 0;
}
